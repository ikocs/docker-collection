# Описание
Репозиторий представляет из себя External Tree для сборки образа Linux с помощью Buildroot. Используется в проекте Соловей для теоминалов связи.

# Сборка
1. Склонирайте этот репозиторий. Рекомендуется использовать домашнюю папку пользователя:
```bash
git clone git@git.ratex.local:software-group/solovey/buildroot-external-tree-solovey.git buildroot-solovey
```
Используется имя папки `buildroot-solovey`, которое используется далее в инструкции. Если будете менять имя папки, используйте его далее в инструкции.

2. Клонирует основной репозиторий buildroot:
```bash
git clone https://gitlab.com/buildroot.org/buildroot.git
```
3. Перейдите в папку куда склонировали основной репозиторий Buildroot.
```bash
cd buildroot
```

4. При сборки использовалась версия `v2024.11`. На других версиях не тестировалось.
```bash
git checkout tags/2024.11 -b 2024.11.x
```
Также этой командой для удобства создается локальная ветка `2024.11.x`.

5. Устанавливаем необходимые пакеты:
```bash
sudo apt-get install libssl-dev libncurses-dev gcc g++ cpio unzip bzip2 libgnutls28-dev make
```

6. Указываем, куда buildroot'у стоит класть собранныую систему:
```bash
make O=../buildroot-solovey/output menuconfig
```
Используется папка с нашем external tree. После выполнения этой команды откроется псевдографическое меню настройки buildroot. Выйдите из него, сохранять изменения не нужно.

7. Переходим в папку, в которую со сборкой:
```bash
cd ../buildroot-solovey/output
```

8. Укажите buildroot'у путь до extrenal tree.
```bash
make BR2_EXTERNAL=../buildroot-solovey menuconfig
```
После выполнения этой команды откроется псевдографическое меню настройки buildroot. Выйдите из него, сохранять изменения не нужно.

9. Установите настройки из defconfig файла.
```bash
make solovey_rpi4b_64_defconfig
```

10. Запустите сборку образа системы.
```bash
make
```

# Использование toolchain в связке с CMake
Для использования набора инструментов для сборки (тулчейна) необходимо сначала собрать образ проекта. Если вы это сделали, то можно подключить уже готовый файл тулчейна.

Файл находится по пути в папке сборки:
```bash
~/buildroot-solovey/output/host/share/buildroot/toolchainfile.cmake
```

Для использования его в c cmake, используйте флаг:
```bash
-DCMAKE_TOOLCHAIN_FILE:FILEPATH=/home/wsl-user/buildroot-solovey/output/host/share/buildroot/toolchainfile.cmake
```

Вы также можете пересобрать только инструменты сборки или запаковать их в архив. Для этого изучите [инструкцию](https://buildroot.org/downloads/manual/manual.html#_advanced_usage) в документации buildroot. Если сайт не открывается, инструкция есть локально в репозитории buildroot: `~/buildroot/docs/using-buildroot-toolchain.adoc`.

При сборке проекта для корректной работы дебагера также пришлось добавить следующие флаги в `CMakeLists.txt`, чтобы компилятор излишне не оптимизировал файлы:
```cmake
set(CMAKE_C_FLAGS "${CMAKE_C_FLAGS} -O0 -g3 -luuid")
set(CMAKE_CXX_FLAGS "${CMAKE_CXX_FLAGS} -O0 -g3 -luuid")
set(CMAKE_EXE_LINKER_FLAGS "${CMAKE_EXE_LINKER_FLAGS} -luuid")
```

## FAQ
1. Если при добавлении новых пакетов, сборка ломается с подобной ошибкой:
```bash
fatal error: gnutls/gnutls.h: No such file or directory
```
Попробуйте поискать недостающий в системе пакет. Для этого используйте утилиту `apt-file`:
```bash
sudo apt install apt-file
```
```
apt-file search gnutls/gnutls.h
```
Утилита покажет недостающий пакет. Могут понадобится недостающие команды, вроде обновления индексов. Следайте подсказкам, которые будут отображены в темринале. В [случае выше](https://adaptivesupport.amd.com/s/question/0D54U000086ca7RSAQ/toolsmkeficapsulec2110-fatal-error-gnutlsgnutlsh-no-such-file-or-directory?language=en_US) было необходимо доустановить `libgnutls28-dev`.